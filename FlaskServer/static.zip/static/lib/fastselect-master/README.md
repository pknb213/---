#Fast select
Fastselect is lightweight browser plugin for enhanced select elements based on jQuery. Enables fast and sensible UI upgrade of select element with features like option searching and remote dataset loading.

[Examples and documentation can be found here](http://dbrekalo.github.io/fastselect)
